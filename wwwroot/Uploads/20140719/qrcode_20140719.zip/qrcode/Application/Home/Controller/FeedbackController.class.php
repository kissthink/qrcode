<?php
// 本类由系统自动生成，仅供测试用途
namespace Home\Controller;
class FeedbackController extends HomeController {
    public function index(){
	    
        
        $this->display();
    }
    
}